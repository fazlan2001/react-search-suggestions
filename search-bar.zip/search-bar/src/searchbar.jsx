import { useState } from 'react';
import './searchbar.css'; // Make sure to import your CSS file

function Searchbar() {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  const data = ['Milk','Eggs','Bread','Butter','Cheese','Yogurt','Chicken','Beef','Fish',
                'Rice','Pasta','Flour','Sugar','Salt','Pepper','Vegetable Oil','Olive Oil',
                'Honey','Cereal','Oats','Peanut Butter','Jelly','Canned Tomatoes','Canned Beans',
                'Frozen Vegetables','Frozen Fruits','Snack Bars','Potato Chips','Cookies','Ice Cream',
                'Soft Drinks','Juice','Coffee','Tea','Herbs','Spices','Nuts','Dried Fruits','Granola',
                'Pizza','Tortillas','Condiments','Sauces'];
// Sample data for suggestions

  const handleInputChange = (event) => {
    const value = event.target.value;
    setQuery(value);
    
    // Filter suggestions based on the input
    if (value) {
      const filteredSuggestions = data.filter(item =>
        item.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(filteredSuggestions);
    } else {
      setSuggestions([]);
    }
  };

  return (
    <div className="search-container">
      <input
        type="text"
        value={query}
        onChange={handleInputChange}
        placeholder="Search..."
        className="search-input"
      />
      {suggestions.length > 0 && (
        <div className="suggestions-container">
          {suggestions.map((suggestion, index) => (
            <div key={index} className="suggestion-card">
              {suggestion}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Searchbar;
