import { useState } from 'react';
import './App.css';
import SearchBar from './searchbar'; // Import the SearchBar component

function App() {

  return (
    <>
      <SearchBar /> {/* Add SearchBar here */}
    </>
  );
}

export default App;